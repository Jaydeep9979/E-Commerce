<?php
    session_start();
    include('dbhandler.php');
    



        if($_POST['username']!='' && $_POST['password']!='')
        {
            $username=$_POST['username'];
            $password=$_POST['password'];
            $valid="select * from customer where `email`='$username' and `password`='$password'";
            $valid_user=mysqli_query($dbhandler,$valid);
            $no_user=mysqli_num_rows($valid_user);
           

            if($no_user==1)
            {
              echo "success";
              $arr =mysqli_fetch_assoc($valid_user);
              $_SESSION['customer']=$arr['customer_id'];
            }
            else
            {
              echo "invalid username or password";
            }

        }
        else
        {
            echo "Enter Email id or password";

        }

 ?>

