<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="SI_20190511_232102.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p></p>Jaydeep Mahajan<a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
       <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="javascript:void(0)">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="dashboard.php"><i class="fa fa-circle-o"></i>Home Page</a></li>
         
          </ul>
        </li>
       
      </ul>

       <ul class="sidebar-menu" data-widget="tree">
      
        <li class="active treeview">
          <a href="javascript:void(0)">
            <i class="fa fa-dashboard"></i> <span>Manage Catogory</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="cat.php"><i class="fa fa-circle-o"></i>Main Categories</a></li>
            <li><a href="subcat.php"><i class="fa fa-circle-o"></i>Sub Categories</a></li>
            <li><a href="childcat.php"><i class="fa fa-circle-o"></i>Child Categories</a></li>
           


          </ul>
        </li>
       
      </ul>
      
           <ul class="sidebar-menu" data-widget="tree">
      
        <li class="active treeview">
          <a href="javascript:void(0)">
            <i class="fa fa-dashboard"></i> <span>Manage Slider</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="slider.php"><i class="fa fa-circle-o"></i>Slider</a></li>
           

          </ul>
        </li>
       
      </ul>


             <ul class="sidebar-menu" data-widget="tree">
      
        <li class="active treeview">
          <a href="javascript:void(0)">
            <i class="fa fa-dashboard"></i> <span>Manage Testimonials</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="test.php"><i class="fa fa-circle-o"></i>Testimonial Profiles</a></li>
           

          </ul>
        </li>
       
      </ul>




            <ul class="sidebar-menu" data-widget="tree">
      
        <li class="active treeview">
          <a href="javascript:void(0)">
            <i class="fa fa-dashboard"></i> <span>Product</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="product.php"><i class="fa fa-circle-o"></i>Add Product</a></li>
           

          </ul>
        </li>
       
      </ul>

      


    </section>
    <!-- /.sidebar -->
  </aside>