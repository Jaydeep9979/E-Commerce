<?php
$server="localhost";
$username="root";
$password="";
$database="beebom";

$dbhandler=mysqli_connect($server,$username,$password,$database);
// if($dbhandler=='')
// {
// 	echo "Connection Failed".mysql_connect_error();
// }
// else
// {
// 	echo "Connection established";
// }
?>