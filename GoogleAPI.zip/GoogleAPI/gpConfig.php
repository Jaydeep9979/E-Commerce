<?php
session_start();

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '547013913493-004546ducv9bcc5u0hirvkqr1glu2oeu.apps.googleusercontent.com'; //Google client ID
$clientSecret = 'o2IJxlvlRtq09rkakuVWxZMv'; //Google client secret
$redirectURL = 'http://localhost/GoogleAPI/index.php'; //Callback URL

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to CodexWorld.com');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>